<?php
defined('ABSPATH') || die();
?>
<div class="wp-active-we-archive no-post-found">
    <p><?php _e('Unfortunately, nothing was found!', 'wp-active-widgets-elementor'); ?></p>
</div>
