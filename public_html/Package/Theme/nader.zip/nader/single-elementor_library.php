<?php
defined( 'ABSPATH' ) || die();

get_header();

?>
    <div class="main">
		<?php the_content(); ?>
    </div><!-- /.main -->
<?php

get_footer();

