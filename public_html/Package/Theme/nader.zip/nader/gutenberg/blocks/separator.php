<?php
defined('ABSPATH') || die();

?>
</div>
<?php
if (is_admin()) {
    echo '<br><hr><br>';
}
?>
<div class="sidebar-item p-4 mb-4">
