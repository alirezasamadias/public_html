<?php
defined('ABSPATH') || die();

?>
<p class="no-post-block col-12">
   <?php _e('Unfortunately, there is no post!', 'nader'); ?>
</p>
