<?php
defined('ABSPATH') || die();
?>
<div class="si-header d-flex align-items-center gap-3">
    <span class="icon d-flex align-items-center justify-content-center"><?php echo $args['icon']; ?></span>
    <span><?php echo $args['title']; ?></span>
</div>