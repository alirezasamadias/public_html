<?php
defined('ABSPATH') || die();
?>

<div class="post-tags mt-4 pt-3">
    <?php the_tags('برچسب ها: ', ', '); ?>
</div>
