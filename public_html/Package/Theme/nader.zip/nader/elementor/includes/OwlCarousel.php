<?php

use Elementor\Controls_Manager;

defined('ABSPATH') || die();

trait OwlCarousel
{

    private function OwlSettings()
    {

        $this->start_controls_section('slider-settings', ['label' => 'تنظیمات اسلایدر']);

        RP_Utils::NUMBER_FIELD($this, 'items', 'تعداد اسلاید برای نمایش', 1, 12, 1, 3);
        RP_Utils::NUMBER_FIELD($this, 'slideBy', 'تعداد اسلاید در هر حرکت', 1, 100, 1, 1);
        RP_Utils::NUMBER_FIELD($this, 'smartSpeed', 'سرعت انتقال', 100, 1000, 10, 300);
        RP_Utils::SWITCH_FIELD($this, 'loop', 'حلقه بی نهایت');
        RP_Utils::SWITCH_FIELD($this, 'autoplay', 'پخش خودکار');
        RP_Utils::NUMBER_FIELD($this, 'autoplayTimeout', 'سرعت پخش خودکار', 1000, 10000, 100, 3000, true, 'autoplay', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'autoplayHoverPause', 'توقف پخش خودکار در هاور', 'yes', '', 'autoplay', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'dots', 'نقاط کنترلی');
        RP_Utils::NUMBER_FIELD($this, 'dotsEach', 'تعداد اسلاید در نقطه کنترلی', 1, 10, 1, 1, true, 'dots', 'yes');
        $arrows = [
            ''           => 'غیر فعال',
            'default'    => 'پیشفرض',
            'custom-btn' => 'دلخواه'
        ];
        RP_Utils::SELECT_FIELD($this, 'nav', 'دکمه های کنترلی', $arrows, 'default');
        RP_Utils::TXT_FIELD($this, 'NextNavText', 'دکمه بعدی', '', false, 'nav', 'custom-btn');
        RP_Utils::TXT_FIELD($this, 'PrevNavText', 'دکمه قبلی', '', false, 'nav', 'custom-btn');

        RP_Utils::NUMBER_FIELD($this, 'margin', 'فاصله بین آیتم ها', 0, 100, 1, 15);

        RP_Utils::SWITCH_FIELD($this, 'center', 'حالت وسط');

        RP_Utils::SWITCH_FIELD($this, 'mouseDrag', 'دراگ با موس', 'yes');

        $this->add_responsive_control(
            'box-padding-top',
            [
                'label'       => 'پدینگ بالای باکس',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-stage' => 'padding-top: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_responsive_control(
            'box-padding-bottom',
            [
                'label'       => 'پدینگ پایین باکس',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-stage' => 'padding-bottom: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_control(
            'stage-padding',
            [
                'label'       => 'پدینگ اطراف باکس',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
            ]
        );

        RP_Utils::SWITCH_FIELD($this, 'responsive', 'ریسپانسیو');

        $repeater = new \Elementor\Repeater();

        RP_Utils::NUMBER_FIELD($repeater, 'breakpoint', 'نقطه شکست', 320, 1440, 1, 1024);
        RP_Utils::NUMBER_FIELD($repeater, 'items', 'تعداد اسلاید برای نمایش', 1, 12);
        RP_Utils::NUMBER_FIELD($repeater, 'slideBy', 'تعداد اسلاید در هر حرکت', 1, 100, 1, 1);
        RP_Utils::NUMBER_FIELD($repeater, 'margin', 'فاصله بین آیتم ها', 0, 100, 1, 15);
        $repeater->add_control(
            'stage-padding',
            [
                'label'       => 'پدینگ اطراف باکس',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
            ]
        );

        $this->add_control(
            'responsive_breakpoints',
            [
                'label'         => 'breakpoints',
                'type'          => \Elementor\Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'title_field'   => 'از {{{ breakpoint }}}px به بالا',
                'prevent_empty' => false,
                'condition'     => [
                    'responsive' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();

    }

    private function RenderOwlSettings()
    {
        $settings = $this->get_settings_for_display();

        $data = [];
        if (!empty($settings['items'])) {
            $data['items'] = $settings['items'];
        }

        if (!empty($settings['slideBy'])) {
            $data['slideBy'] = $settings['slideBy'];
        }

        if (!empty($settings['smartSpeed'])) {
            $data['smartSpeed'] = $settings['smartSpeed'];
        }

        if (!empty($settings['autoplayTimeout'])) {
            $data['autoplayTimeout'] = $settings['autoplayTimeout'];
        }

        if (!empty($settings['dotsEach'])) {
            $data['dotsEach'] = $settings['dotsEach'];
        }

        if (!empty($settings['margin'])) {
            $data['margin'] = $settings['margin'];
        }

        if (!empty($settings['stage-padding'])) {
            $data['stagePadding'] = $settings['stage-padding']['size'];
        }

        $data['responsiveRefreshRate'] = 100;

        $data['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
        $data['loop']               = $settings['loop'] === 'yes' ? true : false;
        $data['dots']               = $settings['dots'] === 'yes' ? true : false;
        $data['center']             = $settings['center'] === 'yes' ? true : false;
        $data['autoplayHoverPause'] = $settings['autoplayHoverPause'] === 'yes' ? true : false;
        $data['rtl']                = is_rtl();
        $data['mouseDrag']          = $settings['mouseDrag'] === 'yes' ? true : false;


        if (!empty($settings['nav'])) {

            if ($settings['nav'] === 'default') {
                $data['nav'] = true;
                $next_icon   = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M13.172 12l-4.95-4.95 1.414-1.414L16 12l-6.364 6.364-1.414-1.414z"/></svg>';
                $prev_icon   = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M10.828 12l4.95 4.95-1.414 1.414L8 12l6.364-6.364 1.414 1.414z"/></svg>';

                $data['navText'] = [$next_icon, $prev_icon];

            } else {
                $data['navNextBtn'] = $settings['NextNavText'];
                $data['navPrevBtn'] = $settings['PrevNavText'];
            }

        } else {
            $data['nav'] = false;
        }

        if (!empty($settings['responsive']) && !empty($settings['responsive_breakpoints'])) {

            $breakpoints = $settings['responsive_breakpoints'];

            $temp = [];
            foreach ($breakpoints as $breakpoint) {

                $temp[$breakpoint['breakpoint']] = [
                    'items'        => $breakpoint['items'],
                    'slideBy'      => $breakpoint['slideBy'],
                    'margin'       => $breakpoint['margin'],
                    'stagePadding' => $breakpoint['stage-padding']['size'],
                ];
            }

            $data['responsive'] = $temp;
        }

        return $data;
    }

    private function OwlStylesNextPrevBtn()
    {

        // next prev arrows styles
        $this->start_controls_section('slider-nav-styles', [
            'label'     => 'استایل دکمه های بعدی و قبلی',
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [
                'nav' => 'default'
            ]
        ]);

        RP_Utils::TAB_START($this, 'nav-btn');

        $this->add_responsive_control(
            'nav-side-space-normal',
            [
                'label'       => 'فاصله از کنار',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-nav button.owl-next' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .owl-carousel .owl-nav button.owl-prev' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-width-normal', 'عرض', 20, 100, 40, '.owl-carousel .owl-nav button', 'width');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-height-normal', 'ارتفاع', 20, 200, 40, '.owl-carousel .owl-nav button', 'height');
        $this->add_control(
            'nav-icon-size-normal',
            [
                'label'       => 'اندازه آیکون',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 14,
                        'max' => 40,
                    ],
                ],
                'default'     => [
                    'size' => 18
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-nav button svg' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );
        RP_Utils::COLOR_FIELD($this, 'nav-icon-color-normal', 'رنگ آیکون', '', '.owl-carousel .owl-nav button svg', 'fill');
        RP_Utils::BACKGROUND_FIELD($this, 'nav-bg-normal', '.owl-carousel .owl-nav button');
        RP_Utils::BORDER_FIELD($this, 'nav-border-normal', 'بوردر', '.owl-carousel .owl-nav button');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-border-radius-normal', 'خمیدگی', 0, 100, 50, '.owl-carousel .owl-nav button', 'border-radius');
        RP_Utils::SHADOW_FIELD($this, 'nav-box-shadow-normal', 'سایه', '.owl-carousel .owl-nav button');

        RP_Utils::TAB_MIDDLE($this, 'nav-btn');

        $this->add_responsive_control(
            'nav-side-space-hover',
            [
                'label'       => 'فاصله از کنار',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default'     => [
                    'size' => 0
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-nav button.owl-next:hover' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .owl-carousel .owl-nav button.owl-prev:hover' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-width-hover', 'عرض', 20, 100, 40, '.owl-carousel .owl-nav button:hover', 'width');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-height-hover', 'ارتفاع', 20, 100, 40, '.owl-carousel .owl-nav button:hover', 'height');
        $this->add_control(
            'nav-icon-size-hover',
            [
                'label'       => 'اندازه آیکون',
                'type'        => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min' => 14,
                        'max' => 40,
                    ],
                ],
                'default'     => [
                    'size' => 18
                ],
                'selectors'   => [
                    '{{WRAPPER}} .owl-carousel .owl-nav button:hover svg' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );
        RP_Utils::COLOR_FIELD($this, 'nav-icon-color-hover', 'رنگ آیکون', '', '.owl-carousel .owl-nav button:hover svg', 'fill');
        RP_Utils::BACKGROUND_FIELD($this, 'nav-bg-hover', '.owl-carousel .owl-nav button:hover');
        RP_Utils::BORDER_FIELD($this, 'nav-border-hover', 'بوردر', '.owl-carousel .owl-nav button:hover');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'nav-border-radius-hover', 'خمیدگی', 0, 100, 50, '.owl-carousel .owl-nav button:hover', 'border-radius');
        RP_Utils::SHADOW_FIELD($this, 'nav-box-shadow-hover', 'سایه', '.owl-carousel .owl-nav button:hover');

        RP_Utils::TAB_END($this);
        $this->end_controls_section();

    }

    private function OwlStylesDotSettings()
    {


        // dots styles
        $this->start_controls_section('slider-dots-styles', [
            'label'     => 'استایل نقاط کنترلی',
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [
                'dots' => 'yes'
            ]
        ]);

        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-margin-top', 'فاصله از بالا', 0, 100, 50, '.owl-carousel .owl-dots', 'margin-top');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-gap', 'فاصله بین', 0, 20, 4, '.owl-carousel .owl-dots', 'gap');

        RP_Utils::TAB_START($this, 'dots-btn');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-width-normal', 'عرض', 6, 40, 12, '.owl-carousel .owl-dots button.owl-dot', 'width');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-height-normal', 'ارتفاع', 6, 40, 12, '.owl-carousel .owl-dots button.owl-dot', 'height');
        RP_Utils::BACKGROUND_FIELD($this, 'dots-bg-normal', '.owl-carousel .owl-dots button.owl-dot');
        RP_Utils::BORDER_FIELD($this, 'dots-border-normal', 'بوردر', '.owl-carousel .owl-dots button.owl-dot');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-border-radius-normal', 'خمیدگی', 0, 50, 50, '.owl-carousel .owl-dots button.owl-dot', 'border-radius');

        RP_Utils::TAB_MIDDLE_($this, 'dots-btn', 'فعال');

        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-width-active', 'عرض', 6, 40, 24, '.owl-carousel .owl-dots button.owl-dot.active', 'width');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-height-active', 'ارتفاع', 6, 40, 12, '.owl-carousel .owl-dots button.owl-dot.active', 'height');
        RP_Utils::BACKGROUND_FIELD($this, 'dots-bg-active', '.owl-carousel .owl-dots button.owl-dot.active');
        RP_Utils::BORDER_FIELD($this, 'dots-border-active', 'بوردر', '.owl-carousel .owl-dots button.owl-dot.active');
        RP_Utils::SLIDER_FIELD_PIX_STYLE($this, 'dots-border-radius-active', 'خمیدگی', 0, 50, 50, '.owl-carousel .owl-dots button.owl-dot.active', 'border-radius');

        RP_Utils::TAB_END($this);

        $this->end_controls_section();

    }

}

