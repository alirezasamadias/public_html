<?php

namespace Elementor;

defined('ABSPATH') || die();

use RP_Utils;

class NaderSingleShare extends Widget_Base{

    public function get_name()
    {
        return 'NaderSingleShare';
    }

    public function get_title()
    {
        return PLUGIN_NAME_FA . ' : انتشار پست';
    }

    public function get_icon()
    {
        return 'nader-widget eicon-share';
    }

    public function get_categories()
    {
        return [PLUGIN_NAME];
    }

    protected function register_controls()
    {
        RP_Utils::SECTION_START($this, 'settings', 'تنظیمات');
        RP_Utils::SWITCH_FIELD($this, 'enable-facebook', 'facebook', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'enable-twitter', 'twitter', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'enable-linkedin', 'linkedin', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'enable-whatsapp', 'whatsapp', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'enable-telegram', 'telegram', 'yes');
        RP_Utils::SWITCH_FIELD($this, 'enable-copy-link', 'کپی لینک', 'yes');
        RP_Utils::SECTION_END($this);


        RP_Utils::SECTION_START($this, 'styles', 'استایل', 'style');
        RP_Utils::IconUtils($this, 'share', '', 'a');
        RP_Utils::SECTION_END($this);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $facebook = $settings['enable-facebook'];
        $twitter = $settings['enable-twitter'];
        $linkedin = $settings['enable-linkedin'];
        $whatsapp = $settings['enable-whatsapp'];
        $telegram = $settings['enable-telegram'];
        $copy = $settings['enable-copy-link'];

        $permalink = esc_url(get_the_permalink());

        ?>

        <ul class="nader-share d-flex flex-wrap align-items-center justify-content-end">
            <?php if (!empty($facebook)) { ?>
                <li>
                    <a href="https://www.facebook.com/sharer.php?u=<?php echo $permalink; ?>" target="_blank"
                       title="<?php esc_html_e('Share on Facebook', 'nader'); ?>"
                       class="d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M14 19h5V5H5v14h7v-5h-2v-2h2v-1.654c0-1.337.14-1.822.4-2.311A2.726 2.726 0 0 1 13.536 6.9c.382-.205.857-.328 1.687-.381.329-.021.755.005 1.278.08v1.9H16c-.917 0-1.296.043-1.522.164a.727.727 0 0 0-.314.314c-.12.226-.164.45-.164 1.368V12h2.5l-.5 2h-2v5zM4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/>
                        </svg>
                    </a>
                </li>
            <?php }
            if (!empty($twitter)) { ?>
                <li>
                    <a href="https://twitter.com/intent/tweet?text=<?php echo $permalink; ?>" target="_blank"
                       title="<?php esc_html_e('Share on Twitter', 'nader'); ?>"
                       class="d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M15.3 5.55a2.9 2.9 0 0 0-2.9 2.847l-.028 1.575a.6.6 0 0 1-.68.583l-1.561-.212c-2.054-.28-4.022-1.226-5.91-2.799-.598 3.31.57 5.603 3.383 7.372l1.747 1.098a.6.6 0 0 1 .034.993L7.793 18.17c.947.059 1.846.017 2.592-.131 4.718-.942 7.855-4.492 7.855-10.348 0-.478-1.012-2.141-2.94-2.141zm-4.9 2.81a4.9 4.9 0 0 1 8.385-3.355c.711-.005 1.316.175 2.669-.645-.335 1.64-.5 2.352-1.214 3.331 0 7.642-4.697 11.358-9.463 12.309-3.268.652-8.02-.419-9.382-1.841.694-.054 3.514-.357 5.144-1.55C5.16 15.7-.329 12.47 3.278 3.786c1.693 1.977 3.41 3.323 5.15 4.037 1.158.475 1.442.465 1.973.538z"/>
                        </svg>
                    </a>
                </li>
            <?php }
            if (!empty($linkedin)) { ?>
                <li>
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $permalink; ?>"
                       target="_blank"
                       title="<?php esc_html_e('Share on LinkedIn', 'nader'); ?>"
                       class="d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm1 2v14h14V5H5zm2.5 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm-1 1h2v7.5h-2V10zm5.5.43c.584-.565 1.266-.93 2-.93 2.071 0 3.5 1.679 3.5 3.75v4.25h-2v-4.25a1.75 1.75 0 0 0-3.5 0v4.25h-2V10h2v.43z"/>
                        </svg>
                    </a>
                </li>
            <?php }
            if (!empty($whatsapp)) { ?>
                <li>
                    <a href="https://api.whatsapp.com/send?text=*<?php the_title(); ?>*<?php echo $permalink; ?>"
                       target="_blank"
                       title="<?php esc_html_e('Share on Whatsapp', 'nader'); ?>"
                       class="d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M7.253 18.494l.724.423A7.953 7.953 0 0 0 12 20a8 8 0 1 0-8-8c0 1.436.377 2.813 1.084 4.024l.422.724-.653 2.401 2.4-.655zM2.004 22l1.352-4.968A9.954 9.954 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10a9.954 9.954 0 0 1-5.03-1.355L2.004 22zM8.391 7.308c.134-.01.269-.01.403-.004.054.004.108.01.162.016.159.018.334.115.393.249.298.676.588 1.357.868 2.04.062.152.025.347-.093.537a4.38 4.38 0 0 1-.263.372c-.113.145-.356.411-.356.411s-.099.118-.061.265c.014.056.06.137.102.205l.059.095c.256.427.6.86 1.02 1.268.12.116.237.235.363.346.468.413.998.75 1.57 1l.005.002c.085.037.128.057.252.11.062.026.126.049.191.066a.35.35 0 0 0 .367-.13c.724-.877.79-.934.796-.934v.002a.482.482 0 0 1 .378-.127c.06.004.121.015.177.04.531.243 1.4.622 1.4.622l.582.261c.098.047.187.158.19.265.004.067.01.175-.013.373-.032.259-.11.57-.188.733a1.155 1.155 0 0 1-.21.302 2.378 2.378 0 0 1-.33.288 3.71 3.71 0 0 1-.125.09 5.024 5.024 0 0 1-.383.22 1.99 1.99 0 0 1-.833.23c-.185.01-.37.024-.556.014-.008 0-.568-.087-.568-.087a9.448 9.448 0 0 1-3.84-2.046c-.226-.199-.435-.413-.649-.626-.89-.885-1.562-1.84-1.97-2.742A3.47 3.47 0 0 1 6.9 9.62a2.729 2.729 0 0 1 .564-1.68c.073-.094.142-.192.261-.305.127-.12.207-.184.294-.228a.961.961 0 0 1 .371-.1z"/>
                        </svg>
                    </a>
                </li>
            <?php }
            if (!empty($telegram)) { ?>
                <li>
                    <a href="https://telegram.me/share/url?url=<?php echo $permalink; ?>&text=<?php the_title(); ?>"
                       target="_blank"
                       title="<?php esc_html_e('Share on Telegram', 'nader'); ?>"
                       class="d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M1.923 9.37c-.51-.205-.504-.51.034-.689l19.086-6.362c.529-.176.832.12.684.638l-5.454 19.086c-.15.529-.475.553-.717.07L11 13 1.923 9.37zm4.89-.2l5.636 2.255 3.04 6.082 3.546-12.41L6.812 9.17z"/>
                        </svg>
                    </a>
                </li>
            <?php } ?>
            <?php if (!empty($copy)) { ?>
                <li>
                    <a href="<?php echo wp_get_shortlink(); ?>"
                       class="clipboard d-flex align-items-center justify-content-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"/>
                            <path d="M17.657 14.828l-1.414-1.414L17.657 12A4 4 0 1 0 12 6.343l-1.414 1.414-1.414-1.414 1.414-1.414a6 6 0 0 1 8.485 8.485l-1.414 1.414zm-2.829 2.829l-1.414 1.414a6 6 0 1 1-8.485-8.485l1.414-1.414 1.414 1.414L6.343 12A4 4 0 1 0 12 17.657l1.414-1.414 1.414 1.414zm0-9.9l1.415 1.415-7.071 7.07-1.415-1.414 7.071-7.07z"/>
                        </svg>
                    </a>
                </li>
            <?php } ?>
        </ul>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new NaderSingleShare());
