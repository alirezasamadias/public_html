<?php
/**
 * Template Name: Nader: طراحی با المنتور (برگه خالی)
 * Template Post Type: page, post, project, team
 */
defined( 'ABSPATH' ) || die();

get_header();
?>
    <div class="main">
		<?php the_content(); ?>
    </div><!-- /.main -->
<?php
get_footer();
